"""
API package for SentinelDNS.
"""