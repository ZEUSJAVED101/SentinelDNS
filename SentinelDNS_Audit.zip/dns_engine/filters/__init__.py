"""
SentinelDNS Filter Engine
"""